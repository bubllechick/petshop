-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 09, 2019 at 09:07 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `petshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `nama` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `pass` varchar(25) NOT NULL,
  `email` varchar(35) NOT NULL,
  `alamat` varchar(35) NOT NULL,
  `no` int(25) NOT NULL,
  `kategori` enum('Own','Pegawai') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`nama`, `username`, `pass`, `email`, `alamat`, `no`, `kategori`) VALUES
('imen', 'imen', '1234', 'hilman.m22@yahoo.com', 'kp.kalibaru rt02/01', 34234, 'Own'),
('timunsuri', 'timun', 'timun', 'timuntimun', 'kp.timun', 234324, 'Pegawai');

-- --------------------------------------------------------

--
-- Table structure for table `input`
--

CREATE TABLE `input` (
  `id` int(25) NOT NULL,
  `kd` varchar(25) NOT NULL,
  `namah` varchar(35) NOT NULL,
  `tgl` date NOT NULL,
  `jumlah` int(25) NOT NULL,
  `harga` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `input`
--

INSERT INTO `input` (`id`, `kd`, `namah`, `tgl`, `jumlah`, `harga`) VALUES
(7, 'nj89', 'snkjnjj', '2019-08-09', 2, 10000),
(16, 'AE43', 'kuntul', '2019-08-09', 3, 45000);

--
-- Triggers `input`
--
DELIMITER $$
CREATE TRIGGER `input_barang` AFTER INSERT ON `input` FOR EACH ROW BEGIN
	UPDATE stok SET jumlah=jumlah+NEW.jumlah
    WHERE kd=NEW.kd;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE `penjualan` (
  `namap` varchar(25) NOT NULL,
  `harga` int(35) NOT NULL,
  `bayar` int(35) NOT NULL,
  `jumlah` int(35) NOT NULL,
  `date` date DEFAULT NULL,
  `kd` varchar(25) NOT NULL,
  `namah` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`namap`, `harga`, `bayar`, `jumlah`, `date`, `kd`, `namah`) VALUES
('kintil', 12000, 230000, 3, '2009-08-19', '12', 'kucing'),
('kui', 12000, 120000, 3, '2009-08-19', 'AE43', 'kill'),
('kintil', 12000, 23000, 2, '2009-08-19', 'AE43', 'kill'),
('ki', 4, 2, 1, '2009-08-19', 'op90', 'kuy'),
('kintil', 12000, 23000, 1, '2009-08-19', 'AE43', 'kill'),
('hui', 12000, 120000, 2, '2009-08-19', 'AE43', 'kill'),
('ko', 12000, 23000, 1, '2009-08-19', 'AE43', 'kill'),
('kintil', 12000, 230000, 2, '2009-08-19', 'AE43', 'kill'),
('hiu', 12000, 230000, 3, '2009-08-19', 'AE43', 'kill'),
('kui', 12000, 230000, 2, '2009-08-19', 'AE43', 'kill'),
('heloo', 4, 4, 1, '2001-08-19', 'op90', 'kuy'),
('hui', 45000, 50000, 1, '2010-08-19', 'AE43', 'kintil'),
('apakamu', 45000, 60000, 1, '2010-08-19', 'AE43', 'kintil'),
('oi', 45000, 45000, 1, '2009-08-19', 'AE43', 'kintil');

--
-- Triggers `penjualan`
--
DELIMITER $$
CREATE TRIGGER `penjaulan_hewan` AFTER INSERT ON `penjualan` FOR EACH ROW BEGIN
	UPDATE stok SET jumlah=jumlah-NEW.jumlah
    WHERE kd = NEW.kd;
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `stok`
--

CREATE TABLE `stok` (
  `id` int(23) NOT NULL,
  `namah` varchar(23) NOT NULL,
  `kd` varchar(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `jumlah` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stok`
--

INSERT INTO `stok` (`id`, `namah`, `kd`, `harga`, `jumlah`) VALUES
(2, 'kuy', 'op90', 4, 0),
(7, 'kintil', 'AE43', 45000, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `input`
--
ALTER TABLE `input`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stok`
--
ALTER TABLE `stok`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `input`
--
ALTER TABLE `input`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `stok`
--
ALTER TABLE `stok`
  MODIFY `id` int(23) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
