/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package koneksi;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author HILMAN
 */
public class koneksi {
     private static Connection mysqlconnect;
    
    public static Connection koneksidata(){
        String database = "jdbc:mysql://localhost/petshop";
        String user = "root";
        String password = "";
        
        if (mysqlconnect==null){            
        
        try{
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            mysqlconnect = (Connection) DriverManager.getConnection(database,user,password);
            
            
        }catch(Exception e){
         JOptionPane.showMessageDialog(null,"Connection failed!");
        }
        }
        return mysqlconnect;
        }
}
